export default function DMCA() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-2">DMCA Removal</h1>
      <p>If you own rights to any content and want it removed, please contact us via Telegram or email.</p>
    </div>
  )
}